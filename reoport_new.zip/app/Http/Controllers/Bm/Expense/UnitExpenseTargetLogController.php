<?php

namespace App\Http\Controllers\Bm\Expense;

use App\Http\Controllers\Controller;
use App\Models\Bm\Expense\UnitExpenseTargetLog;
use Illuminate\Http\Request;

class UnitExpenseTargetLogController extends Controller
{
    
}
