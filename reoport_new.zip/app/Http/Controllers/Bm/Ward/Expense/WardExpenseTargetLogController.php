<?php

namespace App\Http\Controllers\Bm\Ward\Expense;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class WardExpenseTargetLogController extends Controller
{
    //
}
