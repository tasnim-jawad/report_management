<?php

namespace App\Http\Controllers\Unit\Actions;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ExpenseCategoryWise
{
    //
}
