<?php

namespace App\Http\Controllers\Shudhi;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class WardShudhiController extends Controller
{
    //
}
