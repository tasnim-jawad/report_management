<?php

namespace App\Models\Bm\Thana\Expense;

use Illuminate\Database\Eloquent\Model;

class ThanaBmExpenseCategory extends Model
{
    //
}
