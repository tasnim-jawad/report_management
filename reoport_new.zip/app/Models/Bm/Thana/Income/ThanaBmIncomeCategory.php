<?php

namespace App\Models\Bm\Thana\Income;

use Illuminate\Database\Eloquent\Model;

class ThanaBmIncomeCategory extends Model
{
    //
}
