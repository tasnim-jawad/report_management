<?php

namespace App\Models\Bm\Ward\Expense;

use Illuminate\Database\Eloquent\Model;

class WardExpenseTargetLog extends Model
{
    //
}
