<?php

namespace App\Models\Bm\Expense;

use Illuminate\Database\Eloquent\Model;

class UnitExpenseTargetLog extends Model
{
    //
}
