<?php

namespace App\Models\Shudhi;

use Illuminate\Database\Eloquent\Model;

class Shudhi extends Model
{
    //
}
