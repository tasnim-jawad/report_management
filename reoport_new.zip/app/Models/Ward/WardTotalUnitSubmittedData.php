<?php

namespace App\Models\Ward;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WardTotalUnitSubmittedData extends Model
{
    use HasFactory;
}
