<?php

namespace App\Models\Report\Department;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Department6MosjidDawahInfomationCenter extends Model
{
    use HasFactory;
}
