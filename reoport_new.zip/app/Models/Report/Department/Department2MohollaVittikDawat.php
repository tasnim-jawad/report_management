<?php

namespace App\Models\Report\Department;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Department2MohollaVittikDawat extends Model
{
    use HasFactory;
}
