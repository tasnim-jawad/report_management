<?php

namespace App\Models\Report\Department;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Department1TalimulQuran extends Model
{
    use HasFactory;
}
