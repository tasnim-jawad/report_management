<?php

namespace App\Models\Report\Dawat;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dawat4GonoSongjogAndDawatOvijan extends Model
{
    use HasFactory;
}
