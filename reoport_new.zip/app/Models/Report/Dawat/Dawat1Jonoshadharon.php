<?php

namespace App\Models\Report\Dawat;

use Illuminate\Database\Eloquent\Model;

class Dawat1Jonoshadharon extends Model
{
    //
}
