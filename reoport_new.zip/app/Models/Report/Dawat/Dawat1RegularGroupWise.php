<?php

namespace App\Models\Report\Dawat;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Dawat1RegularGroupWise extends Model
{
    use HasFactory;
}
