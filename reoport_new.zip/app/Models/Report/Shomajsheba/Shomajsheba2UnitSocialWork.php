<?php

namespace App\Models\Report\Shomajsheba;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Shomajsheba2UnitSocialWork extends Model
{
    use HasFactory;
}
