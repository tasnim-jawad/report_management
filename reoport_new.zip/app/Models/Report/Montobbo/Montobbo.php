<?php

namespace App\Models\Report\Montobbo;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Montobbo extends Model
{
    use HasFactory;
}
