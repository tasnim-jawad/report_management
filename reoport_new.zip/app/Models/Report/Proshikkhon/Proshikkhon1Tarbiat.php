<?php

namespace App\Models\Report\Proshikkhon;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Proshikkhon1Tarbiat extends Model
{
    use HasFactory;
}
