<?php

namespace App\Models\Report\Rastrio;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rastrio1BishishtoBekti extends Model
{
    use HasFactory;
}
