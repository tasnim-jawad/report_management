<?php

namespace App\Models\Report\Thana\Rastrio;

use Illuminate\Database\Eloquent\Model;

class ThanaRastrio2KormoshuchiBastobayon extends Model
{
    //
}
