<?php

namespace App\Models\Report\Thana\Shomajsheba;

use Illuminate\Database\Eloquent\Model;

class ThanaShomajsheba6EducationAndResearchActivity extends Model
{
    //
}
