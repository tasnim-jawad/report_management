<?php

namespace App\Models\Report\Thana\DawahAndProkashona;

use Illuminate\Database\Eloquent\Model;

class ThanaDawahAndProkashona extends Model
{
    //
}
