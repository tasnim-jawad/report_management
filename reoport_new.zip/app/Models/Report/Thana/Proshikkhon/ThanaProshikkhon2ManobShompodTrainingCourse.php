<?php

namespace App\Models\Report\Thana\Proshikkhon;

use Illuminate\Database\Eloquent\Model;

class ThanaProshikkhon2ManobShompodTrainingCourse extends Model
{
    protected $table = 'thana_proshikkhon3_manob_shompod_training_courses';
}
