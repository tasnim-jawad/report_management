<?php

namespace App\Models\Report\Thana\Proshikkhon;

use Illuminate\Database\Eloquent\Model;

class ThanaProshikkhon1Tarbiat extends Model
{
    //
}
