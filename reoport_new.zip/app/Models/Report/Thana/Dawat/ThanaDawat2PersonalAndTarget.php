<?php

namespace App\Models\Report\Thana\Dawat;

use Illuminate\Database\Eloquent\Model;

class ThanaDawat2PersonalAndTarget extends Model
{
    //
}
