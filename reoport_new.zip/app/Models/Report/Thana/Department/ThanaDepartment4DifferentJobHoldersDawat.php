<?php

namespace App\Models\Report\Thana\Department;

use Illuminate\Database\Eloquent\Model;

class ThanaDepartment4DifferentJobHoldersDawat extends Model
{
    //
}
