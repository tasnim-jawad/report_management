<?php

namespace App\Models\Report\Thana\Department;

use Illuminate\Database\Eloquent\Model;

class ThanaDepartment2MohollaVittikDawat extends Model
{
    //
}
