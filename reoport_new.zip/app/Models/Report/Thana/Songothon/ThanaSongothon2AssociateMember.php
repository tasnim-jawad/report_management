<?php

namespace App\Models\Report\Thana\Songothon;

use Illuminate\Database\Eloquent\Model;

class ThanaSongothon2AssociateMember extends Model
{
    //
}
