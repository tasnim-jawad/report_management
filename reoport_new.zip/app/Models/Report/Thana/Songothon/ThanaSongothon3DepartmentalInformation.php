<?php

namespace App\Models\Report\Thana\Songothon;

use Illuminate\Database\Eloquent\Model;

class ThanaSongothon3DepartmentalInformation extends Model
{
    //
}
