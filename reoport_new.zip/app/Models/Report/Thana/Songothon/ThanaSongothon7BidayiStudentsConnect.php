<?php

namespace App\Models\Report\Thana\Songothon;

use Illuminate\Database\Eloquent\Model;

class ThanaSongothon7BidayiStudentsConnect extends Model
{
    // protected $table = 'thana_songothon7_bidayi_students_connects';
}
