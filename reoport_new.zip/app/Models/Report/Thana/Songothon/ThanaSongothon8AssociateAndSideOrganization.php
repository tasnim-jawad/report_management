<?php

namespace App\Models\Report\Thana\Songothon;

use Illuminate\Database\Eloquent\Model;

class ThanaSongothon8AssociateAndSideOrganization extends Model
{
    protected $table = 'thana_songothon8_associate_and_side_organizations';
}
