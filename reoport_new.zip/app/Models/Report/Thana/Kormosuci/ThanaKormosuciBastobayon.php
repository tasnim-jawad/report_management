<?php

namespace App\Models\Report\Thana\Kormosuci;

use Illuminate\Database\Eloquent\Model;

class ThanaKormosuciBastobayon extends Model
{
    //
}
