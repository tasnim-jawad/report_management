<?php

namespace App\Models\Report\Thana\Montobbo;

use Illuminate\Database\Eloquent\Model;

class ThanaMontobbo extends Model
{
    //
}
