<?php

namespace App\Models\Report\Kormosuci;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class KormosuciBastobayon extends Model
{
    use HasFactory;
}
