<?php

namespace App\Models\Report\Songothon;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Songothon3DepartmentalInformation extends Model
{
    use HasFactory;
}
