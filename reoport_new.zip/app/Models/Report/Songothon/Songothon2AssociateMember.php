<?php

namespace App\Models\Report\Songothon;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Songothon2AssociateMember extends Model
{
    use HasFactory;
}
