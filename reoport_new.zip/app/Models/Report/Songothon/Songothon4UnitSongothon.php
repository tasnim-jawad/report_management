<?php

namespace App\Models\Report\Songothon;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Songothon4UnitSongothon extends Model
{
    use HasFactory;
}
