<?php

namespace App\Models\Report\Ward\Department;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WardDepartment2MohollaVittikDawat extends Model
{
    use HasFactory;
}
