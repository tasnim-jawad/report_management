<?php

namespace App\Models\Report\Ward\Department;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WardDepartment3JuboSomajDawat extends Model
{
    use HasFactory;
}
