<?php

namespace App\Models\Report\Ward\Department;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WardDepartment4DifferentJobHoldersDawat extends Model
{
    use HasFactory;
}
