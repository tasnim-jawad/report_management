<?php

namespace App\Models\Report\Ward\Montobbo;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WardMontobbo extends Model
{
    use HasFactory;
}
