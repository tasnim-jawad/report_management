<?php

namespace App\Models\Report\Ward\DawahAndProkashona;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WardDawahAndProkashona extends Model
{
    use HasFactory;
}
