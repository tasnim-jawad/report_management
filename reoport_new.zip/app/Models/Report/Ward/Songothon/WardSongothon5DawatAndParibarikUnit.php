<?php

namespace App\Models\Report\Ward\Songothon;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WardSongothon5DawatAndParibarikUnit extends Model
{
    use HasFactory;
}
