<?php

namespace App\Models\Report\Ward\Songothon;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WardSongothon8IyanotData extends Model
{
    use HasFactory;
}
