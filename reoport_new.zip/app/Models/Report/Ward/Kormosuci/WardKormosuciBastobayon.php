<?php

namespace App\Models\Report\Ward\Kormosuci;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WardKormosuciBastobayon extends Model
{
    use HasFactory;
}
