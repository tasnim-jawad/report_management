<?php

namespace App\Models\Report\Ward\Proshikkhon;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WardProshikkhon2ManobShompodUnnoyon extends Model
{
    use HasFactory;
}
