<?php

namespace App\Models\Report\Ward\Shomajsheba;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WardShomajsheba3HealthAndFamilyKollan extends Model
{
    use HasFactory;
}
