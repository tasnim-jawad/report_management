<?php

namespace App\Models\Report\Ward\Rastrio;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WardRastrio2KormoshuchiBastobayon extends Model
{
    use HasFactory;
}
