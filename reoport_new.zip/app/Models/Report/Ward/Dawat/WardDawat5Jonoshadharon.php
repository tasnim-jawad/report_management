<?php

namespace App\Models\Report\Ward\Dawat;

use Illuminate\Database\Eloquent\Model;

class WardDawat5Jonoshadharon extends Model
{
    //
}
