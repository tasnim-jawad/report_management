<?php

namespace App\Models\Report\DawahAndProkashona;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DawahAndProkashona extends Model
{
    use HasFactory;
}
